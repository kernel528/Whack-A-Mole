const moles = document.querySelectorAll('.mole');
let points = 0;

function updateScore(){
  points++;
  console.log(points);
}

function whack(event) {
  console.log("whack!")
  updateScore();
}

function setEventListeners(){
  moles.forEach(
    mole => mole.addEventListener('click', whack)
  );
  return moles;
}

setEventListeners();